
String CORP_ID = "";
String PLATFORM = "";
String WORK_DIV = "";
String COMPANY_NO = "";